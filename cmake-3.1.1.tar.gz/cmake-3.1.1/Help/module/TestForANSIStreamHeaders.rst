.. cmake-module:: ../../Modules/TestForANSIStreamHeaders.cmake
