.. cmake-module:: ../../Modules/CPackDeb.cmake
