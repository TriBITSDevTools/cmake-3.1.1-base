.. cmake-module:: ../../Modules/CheckCXXSourceRuns.cmake
