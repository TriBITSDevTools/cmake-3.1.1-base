PARENT_DIRECTORY
----------------

Source directory that added current subdirectory.

This read-only property specifies the source directory that added the
current source directory as a subdirectory of the build.  In the
top-level directory the value is the empty-string.
